# Verification summary

This is a summary of two builder-managed runs of the packaged-source procedure on one Linux machine. It is a record of what was run, not an independent check.

- Run 1 (confined runner) (s437.nspkg.R2.rebuild): outcome **VERIFIED**, 27 runner checks all passing, wall time 1775 s (challenge step 1550 s). Independent axiom probe: navier_stokes_breakdown_R3: ['Classical.choice', 'Quot.sound', 'propext']; navier_stokes_breakdown_periodic: ['Classical.choice', 'Quot.sound', 'propext']. Controls (exit codes): simple_match=0, simple_mismatch=1, simple_nanoda=0, simple_nanoda_mismatch=1.
- Run 2 (confined runner) (s437.nspkg.R2.rebuild2): outcome **VERIFIED**, 28 runner checks all passing, wall time 1825 s (challenge step 1596 s). Independent axiom probe: navier_stokes_breakdown_R3: ['Classical.choice', 'Quot.sound', 'propext']; navier_stokes_breakdown_periodic: ['Classical.choice', 'Quot.sound', 'propext']. Controls (exit codes): simple_match=0, simple_mismatch=1, simple_nanoda=0, simple_nanoda_mismatch=1.

Run 3 (`s437.pubentry.run4`, the public entry point itself, archive v2): outcome **PUBLIC_ENTRYPOINT_VERIFIED**, script exit status 0, 1,834 s; every runner check passed (details in `KNOWN_LIMITS.md`). The independent axiom probe again listed only `propext`, `Classical.choice`, `Quot.sound` for both declarations.

Environment of runs 1 and 2: Ubuntu 24.04.5 LTS, x86_64; Lean 4.34.1; resident toolchains (Lean via elan, Rust, Go, gcc, git) and an already populated Mathlib cache for the pinned revision (`lake exe cache get` found nothing to download in either run). First-time Mathlib download and clean-machine restoration were **not** tested. Network access was used for the git clones of the pinned dependency repositories and of the two checker tools, for crates (`cargo fetch --locked`) and Go modules (`go mod download`).

Compiled from source in each run: the project's own modules in the closure of the checked declarations plus the challenge module (not all 2,659 Lean modules of the repository), and the checker tools. Dependency `.olean` files came from the Mathlib cache and dependency builds.

Not byte-identical: the checker binaries (`nanoda_bin`, `landrun`) built in the two runs differ in length from each other and from an earlier build. The claim is repeatable verification, not reproducible binaries.
