import Euler.BaseEulerInput
import Euler.StaticEulerForceField
import Euler.ParentEulerSobolev

/-! The concrete local base evolution has actual continuous L² jets for
both velocity and pressure force. Consequently its Euler equation holds
strongly in every finite Sobolev order, including endpoint derivatives. -/

noncomputable section

namespace EulerStaticEuler

open Set EulerSmoothLimit EulerLpTranslation EulerParentPacketFrames

variable (P : ℝ) [Fact (0 < P)] (u : SmoothL2Field Space) (C R : ℝ)
  (hC : 0 ≤ C) (hR : 0 ≤ R) (hu : u.HasJetBound C R)
  (hdiv : ∀ x, divergence u.field x=0) (ell : ℝ) (hell : 0 < ell) (hell1 : ell ≤ 1)

def baseSobolevData : SobolevData (baseEvolution P u C R hC hR hu hdiv ell hell hell1) where
  velocity t := localField P u C R hC hR hu hdiv (baseInclusion P C R hC hR t)
  force t := localForceField P u C R hC hR hu hdiv (baseInclusion P C R hC hR t)
  velocity_match t x := (localField_apply P u C R hC hR hu hdiv (baseInclusion P C R hC hR t) x).symm
  force_match t x := (localForceField_apply P u C R hC hR hu hdiv (baseInclusion P C R hC hR t) x).symm
  velocity_continuous n := (localField_jetLp_continuous P u C R hC hR hu hdiv n).comp
    (baseInclusion P C R hC hR).continuous
  force_continuous n := (localForceField_jetLp_continuous P u C R hC hR hu hdiv n).comp
    (baseInclusion P C R hC hR).continuous

end EulerStaticEuler

namespace EulerBaseDatum

open EulerParentPacketFrames

private local instance : Fact (0 < (1 : ℝ)) := ⟨zero_lt_one⟩

def solutionSobolevData (β : ℝ) (hβ : |β| ≤ 1) (ell : ℝ) (hell : 0 < ell) (hell1 : ell ≤ 1) :
    SobolevData (solutionEvolution β hβ ell hell hell1) :=
  EulerStaticEuler.baseSobolevData 1 (field (linear β)) uniformL2Amplitude 1024
    uniformL2Amplitude_nonneg (by norm_num) (field_uniform_jet β hβ)
    (velocity_divergence (linear β)) ell hell hell1

end EulerBaseDatum
