# Notice and credits
- Mathematics and Lean formalisation of the blowup results: OpenAI, repository `https://github.com/openai/NavierStokesAndEuler` at commit `f9e8bc5b38b6e212696e8a30e3e91517af887bbd`, Apache-2.0 (`project/LICENSE`). A 24-file port to Lean 4.34.1 was applied (see `project/UPSTREAM_PROVENANCE.json`).
- Challenge statements: The Formal Conjectures Authors (Google DeepMind), Apache-2.0, as noted in `project/ComparatorChallenges/NavierStokes.lean`.
- Checker: Lean `Comparator` (`leanprover/comparator`), `lean4export`, nanoda (`robsimmons/nanoda_lib`), landrun (`zouuup/landrun`), each at the commit pinned in `project/TOOLS_CLOSURE.json` and `project/DEPENDENCY_CLOSURE.json`.
- Files outside `project/` (this notice, README, TESTING, KNOWN_LIMITS, FILES_R2.txt, scripts/, docs/) were added by the packager. Their licence is to be confirmed by the releasing operator before publication.
- `project/` is byte-identical to the verified R2 candidate (`project/CANDIDATE_CHANGES.md` records how it differs from the earlier verified package: one replaced guide and two added files).
