# Candidate changes relative to the t6 package

Reference package: job `s437.lpb.t6.full` (runner result `VERIFIED`, deposited as `ARTIFACTS/s437.lpb.t6.full.project.tar.gz`).
This candidate: top directory `S412_ESTATE_PORT_v4.34.1__candidate_R2`, archive `s437_ns_candidate_R2.project.tar.gz`. The label "R2" is a descriptive working label; the VERIFIED_SUBMISSIONS protocol (v1.0) defines no candidate-generation numbering.

| Path | Change | Reason |
|---|---|---|
| `RESTORE_AND_VERIFY.md` | replaced | The t6 guide omitted where `nanoda_bin` and `landrun` come from and had no verifiable step list. The new guide documents every restoration step, including the checker tools. |
| `TOOLS_CLOSURE.json` | added | Machine-readable pins for `nanoda_bin` and `landrun` (repository, full commit, Go module version, build method) and the host tool versions observed. |
| `CANDIDATE_CHANGES.md` | added | This record. |

Every other file (all Lean sources, `lakefile.toml`, `lean-toolchain`, `lake-manifest.json`, the Comparator configuration, `DEPENDENCY_CLOSURE.json`, `UPSTREAM_PROVENANCE.json`, `LICENSE`) is byte-identical to the reference package. The verifying runner checks this by exact byte comparison against the node-produced reference and refuses any other difference.

Membership note (reconciling earlier counts): the t6 package has 2672 regular files. Of these, 2669 are the git-tracked files of the executed tree and 3 were added by the runner at packaging time (`DEPENDENCY_CLOSURE.json`, `RESTORE_AND_VERIFY.md`, `UPSTREAM_PROVENANCE.json`). This candidate has 2672 - 0 + 2 = 2674 regular files (the guide is replaced, not added).

The verifying job for this candidate is `s437.nspkg.R2.rebuild`. Its result, step logs and checker bindings are in the returned evidence; nothing in this package states its outcome.
